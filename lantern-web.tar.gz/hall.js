"use strict";
const $ = (id) => document.getElementById(id);
const canvas = $("canvas");
const params = new URLSearchParams(location.search);
const touch = matchMedia("(pointer:coarse)").matches || navigator.maxTouchPoints > 0;
document.body.classList.toggle("touch", touch);
let ready = false;
let settings = { endpoint: "", room: "friends" };
let hudText = "";
let lastOrnaments;
function storageWarning() {
  const output = $("storageWarning");
  output.hidden = false;
  output.textContent = "Browser storage is unavailable. Ornaments last for this visit.";
}
function call(name, types = [], args = [], result = null) {
  return Module.ccall("hall_" + name, result, types, args);
}
function action(name, on) {
  if (ready) call("action", ["string", "number"], [name, Number(on)]);
}
function menu(show) {
  resetInput();
  if (ready) call("menu", ["number"], [Number(show)]);
  document.body.dataset.mode = show ? "menu" : "play";
  $("menu").hidden = show;
  if (show && document.pointerLockElement) document.exitPointerLock();
  if (!show) {
    canvas.focus();
    if (!touch && canvas.requestPointerLock) {
      const pending = canvas.requestPointerLock();
      if (pending && pending.catch) pending.catch(() => {});
    }
  }
}
let syncing = false,
  dirty = false;
function persist() {
  dirty = true;
  if (syncing) return;
  function flush() {
    syncing = true;
    dirty = false;
    Module.FS.syncfs(false, (e) => {
      syncing = false;
      if (e) storageWarning();
      if (dirty) flush();
    });
  }
  flush();
}
function feedbackForm() {
  const form = $("feedbackForm");
  function refresh() {
    for (const el of form.querySelectorAll("[data-pref]")) {
      const value = Module._hall_tune(Number(el.dataset.pref), -1);
      if (el.type === "range") {
        el.step = value === 25 ? "5" : "10";
        el.value = value;
        el.closest("label").querySelector("output").textContent = value + "%";
      } else el.checked = !!value;
    }
  }
  form.oninput = (event) => {
    const el = event.target;
    Module._hall_tune(Number(el.dataset.pref), el.type === "range" ? Number(el.value) : Number(el.checked));
    refresh();
    persist();
  };
  refresh();
}
function panel(which) {
  $("dialogContent").replaceChildren($(which + "Panel").content.cloneNode(true));
  $("dialog").showModal();
  if (which === "feedback") feedbackForm();
  if (which !== "join") return;
  const form = $("roomForm");
  form.elements.server.value = settings.endpoint;
  form.elements.room.value = settings.room;
  function read() {
    const endpoint = form.elements.server.value.trim(),
      room = form.elements.room.value.trim();
    try {
      const u = new URL(endpoint);
      if (!(u.protocol === "wss:" || (u.protocol === "ws:" && location.protocol === "http:"))) throw Error();
      if (!/^[\w-]{1,32}$/.test(room)) throw Error();
    } catch {
      $("joinStatus").textContent = "Enter a valid WebSocket address and room code.";
      return null;
    }
    return { endpoint, room };
  }
  form.onsubmit = (event) => {
    event.preventDefault();
    const input = read();
    if (!input || !ready) return;
    settings = input;
    try {
      localStorage.setItem("lantern-room", JSON.stringify(input));
    } catch {}
    if (call("connect", ["string", "string"], [input.endpoint, input.room], "number")) {
      $("dialog").close();
      menu(false);
    } else $("joinStatus").textContent = "Connection failed. Check the service address and try again.";
  };
  $("solo").onclick = () => {
    if (!ready) return;
    settings = { endpoint: "", room: "friends" };
    try {
      localStorage.setItem("lantern-room", JSON.stringify(settings));
    } catch {}
    call("connect", ["string", "string"], ["", "friends"], "number");
    $("dialog").close();
    menu(false);
  };
  $("invite").onclick = async () => {
    const input = read();
    if (!input) return;
    const url = new URL(location.href);
    url.search = new URLSearchParams({ server: input.endpoint, room: input.room });
    try {
      await navigator.clipboard.writeText(url.href);
      $("joinStatus").textContent = "Invitation copied.";
    } catch {
      $("joinStatus").textContent = url.href;
    }
  };
}
$("join").onclick = () => panel("join");
$("feedback").onclick = () => {
  if (ready) panel("feedback");
};
$("controls").onclick = () => panel("control");
$("credits").onclick = () => panel("credit");
$("close").onclick = () => $("dialog").close();
$("enter").onclick = () => menu(false);
$("menu").onclick = () => menu(true);
document.addEventListener("pointerlockchange", () => {
  if (!ready) return;
  call("lock", ["number"], [Number(document.pointerLockElement === canvas)]);
  if (!touch && !document.pointerLockElement && document.body.dataset.mode === "play") menu(true);
});
function tap(name) {
  action(name, true);
  setTimeout(() => action(name, false), 100);
}
const movement = {
  KeyW: "up",
  ArrowUp: "up",
  KeyS: "down",
  ArrowDown: "down",
  KeyA: "left",
  ArrowLeft: "left",
  KeyD: "right",
  ArrowRight: "right",
  KeyR: "practice",
  KeyE: "interact",
};
function keyInput(e) {
  const control = e.target.closest?.("#feedbackForm [data-pref]");
  if (control && $("dialog").open) {
    const down = e.type === "keydown";
    if (
      control.type === "range" &&
      ["ArrowLeft", "ArrowDown", "ArrowRight", "ArrowUp", "Home", "End"].includes(e.key)
    ) {
      e.preventDefault();
      e.stopImmediatePropagation();
      if (down) {
        const old = Number(control.value);
        const dir = e.key === "ArrowLeft" || e.key === "ArrowDown" ? -1 : 1;
        control.value =
          e.key === "Home"
            ? 0
            : e.key === "End"
              ? 100
              : Math.max(
                  0,
                  Math.min(100, (dir > 0 ? Math.floor(old / 10) + 1 : Math.ceil(old / 10) - 1) * 10),
                );
        control.dispatchEvent(new Event("input", { bubbles: true }));
      }
      return;
    }
    if (control.type === "checkbox" && e.code === "Space") {
      e.preventDefault();
      e.stopImmediatePropagation();
      if (down && !e.repeat) control.click();
      return;
    }
  }
  if (!ready || document.body.dataset.mode !== "play" || $("dialog").open) return;
  const down = e.type === "keydown",
    name = movement[e.code];
  if (name) action(name, down);
  else if (/^Digit[1-5]$/.test(e.code) || e.code === "KeyQ") {
    if (down && !e.repeat) call("choose", ["number"], [e.code === "KeyQ" ? 0 : Number(e.code.slice(-1))]);
  } else if (e.code === "Escape") {
    if (down) menu(true);
  } else return;
  e.preventDefault();
  e.stopImmediatePropagation();
}
window.addEventListener("keydown", keyInput, true);
window.addEventListener("keyup", keyInput, true);
document.addEventListener("mousemove", (e) => {
  if (ready && !touch && document.pointerLockElement === canvas)
    call("look", ["number", "number"], [e.movementX, e.movementY]);
});
const firePointers = new Set();
function pointerFire(id, down) {
  if (down) firePointers.add(id);
  else if (!firePointers.delete(id)) return;
  action("fire", firePointers.size > 0);
}
canvas.addEventListener("pointerdown", (e) => {
  if (e.pointerType === "mouse" && document.body.dataset.mode === "play" && e.button === 0)
    pointerFire(e.pointerId, true);
});
window.addEventListener("pointerup", (e) => {
  if (e.pointerType === "mouse" && e.button === 0) pointerFire(e.pointerId, false);
});
$("practice").onclick = () => tap("practice");
for (const b of document.querySelectorAll("[data-weapon]"))
  b.onclick = () => call("choose", ["number"], [Number(b.dataset.weapon)]);
function bindButton(id, press) {
  const b = $(id);
  b.onpointerdown = (e) => {
    e.preventDefault();
    b.setPointerCapture(e.pointerId);
    press(e.pointerId, true);
  };
  b.onpointerup = b.onpointercancel = b.onlostpointercapture = (e) => press(e.pointerId, false);
}
bindButton("fire", pointerFire);
$("use").onclick = () => tap("interact");
let moving = null,
  looking = null,
  px = 0,
  py = 0;
const stick = $("stick");
function move(e) {
  const rect = stick.getBoundingClientRect(),
    x = (e.clientX - rect.left - rect.width / 2) / (rect.width / 2),
    y = (e.clientY - rect.top - rect.height / 2) / (rect.height / 2);
  for (const [name, down] of [
    ["left", x < -0.2],
    ["right", x > 0.2],
    ["up", y < -0.2],
    ["down", y > 0.2],
  ])
    action(name, down);
  const magnitude = Math.max(1, Math.hypot(x, y));
  stick.firstElementChild.style.transform =
    "translate(" + (x / magnitude) * 28 + "px," + (y / magnitude) * 28 + "px)";
}
function releaseMove() {
  moving = null;
  for (const name of ["left", "right", "up", "down"]) action(name, false);
  stick.firstElementChild.style.transform = "";
}
stick.onpointerdown = (e) => {
  if (moving !== null) return;
  e.preventDefault();
  moving = e.pointerId;
  stick.setPointerCapture(moving);
  move(e);
};
stick.onpointermove = (e) => {
  if (e.pointerId === moving) move(e);
};
stick.onpointerup =
  stick.onpointercancel =
  stick.onlostpointercapture =
    (e) => {
      if (e.pointerId === moving) releaseMove();
    };
const lookTaps = new LookTaps();
canvas.addEventListener("pointerdown", (e) => {
  if (e.pointerType === "mouse" || !ready || document.body.dataset.mode !== "play") return;
  e.preventDefault();
  if (looking !== null) {
    lookTaps.reset();
    return;
  }
  looking = e.pointerId;
  px = e.clientX;
  py = e.clientY;
  canvas.setPointerCapture(looking);
  call("lock", ["number"], [1]);
  if (lookTaps.down(e)) pointerFire(looking, true);
});
canvas.addEventListener("pointermove", (e) => {
  if (e.pointerId !== looking) return;
  lookTaps.move(e);
  call("look", ["number", "number"], [e.clientX - px, e.clientY - py]);
  px = e.clientX;
  py = e.clientY;
});
canvas.onpointerup =
  canvas.onpointercancel =
  canvas.onlostpointercapture =
    (e) => {
      if (e.pointerId !== looking) return;
      if (e.type === "pointerup") lookTaps.up(e);
      else lookTaps.reset();
      pointerFire(looking, false);
      looking = null;
    };
function resetInput() {
  releaseMove();
  looking = null;
  lookTaps.reset();
  firePointers.clear();
  for (const name of ["fire", "interact", "practice"]) action(name, false);
}
window.addEventListener("blur", resetInput);
document.addEventListener("visibilitychange", () => {
  if (document.hidden) resetInput();
});
window.addEventListener("pagehide", () => {
  resetInput();
  if (ready) call("connect", ["string", "string"], ["", "friends"], "number");
});
window.addEventListener("pageshow", (e) => {
  if (e.persisted && ready && settings.endpoint)
    call("connect", ["string", "string"], [settings.endpoint, settings.room], "number");
});
function resize() {
  if (!ready) return;
  const width = canvas.parentElement.clientWidth;
  const height = canvas.parentElement.clientHeight;
  const scale = Math.min(1, 960 / Math.max(width, height), 540 / Math.min(width, height));
  const bufferWidth = Math.max(1, Math.round(width * scale));
  const bufferHeight = Math.max(1, Math.round(height * scale));
  call("resize", ["number", "number"], [bufferWidth, bufferHeight]);
}
window.addEventListener("resize", () => {
  resetInput();
  resize();
});
function updateHUD(text) {
  if (text === hudText) return;
  hudText = text;
  const [
    weapon,
    number,
    bells,
    visitors,
    wave,
    days,
    players,
    connection,
    hint,
    space,
    ornaments,
    mark,
    slow,
    captions,
    tally,
    contrast,
    date,
    rear,
    motion,
    missionTools,
    unlocked,
    hearts,
    stage,
    armor,
    stageCount,
    hurt,
  ] = text.split("|");
  if (lastOrnaments !== undefined && lastOrnaments !== ornaments) persist();
  lastOrnaments = ornaments;
  $("weaponName").textContent = weapon;
  $("bells").textContent = missionTools ? hearts : bells;
  $("bellsLabel").textContent = missionTools ? "hearts" : "bells";
  $("visitors").textContent = missionTools ? stage + "/" + (stageCount || 20) : visitors;
  $("visitorsLabel").textContent = missionTools ? "stage" : "visitors";
  $("days").textContent = days;
  $("connection").textContent = connection + (connection === "Live room" ? " · " + players + "/8" : "");
  $("hint").textContent = hint;
  const art = "games/kalender2026/assets/";
  const outline = contrast === "1" ? "-contrast" : "";
  $("hitMark").hidden = !mark;
  if (mark) $("hitMark").setAttribute("src", art + mark + outline + ".png");
  $("snowStatus").hidden = !slow;
  if (slow) {
    $("snowStatus")
      .querySelector("img")
      .setAttribute("src", art + "boot" + outline + ".png");
    $("snowStatus").querySelector("span").textContent = slow;
  }
  $("snowStatus").classList.toggle("brush", slow === "Recovered" && Number(motion) > 0);
  $("bells").classList.toggle("scored", tally === "1" && Number(motion) > 0);
  const notice = [date, rear, captions]
    .filter(Boolean)
    .filter((v, i, a) => a.indexOf(v) === i)
    .join(" · ");
  if ($("feedbackText").textContent !== notice) $("feedbackText").textContent = notice;
  const inDispatch = space === "1" && !!missionTools;
  $("hud").classList.toggle("wounded", inDispatch && hurt === "1");
  $("armorStat").hidden = !inDispatch;
  $("armor").textContent = armor || "0";
  $("practice").hidden = !inDispatch && Number(visitors) > 0;
  $("practiceLabel").textContent = inDispatch ? "Kick" : "Ring bell";
  $("practice").title = inDispatch ? "Quick kick (R)" : "Ring the hall practice bell";
  for (const b of document.querySelectorAll("[data-weapon]")) {
    b.dataset.hallName ??= b.getAttribute("aria-label");
    const name = missionTools ? missionTools.split(",")[Number(b.dataset.weapon) - 1] : b.dataset.hallName;
    b.setAttribute("aria-label", name);
    b.title = name;
    const icon = b.querySelector("img");
    icon.dataset.hallSrc ??= icon.getAttribute("src");
    const missionGun = ["sidearm", "freezer", "rpg", "shrinker", "twins"][Number(b.dataset.weapon) - 1];
    const src =
      space === "1" && missionTools
        ? "games/kalender2026/missions/day_01/rack-" + missionGun + ".png"
        : icon.dataset.hallSrc;
    if (icon.getAttribute("src") !== src) icon.setAttribute("src", src);
    if (missionTools && space !== "1")
      b.dataset.short = ["PST", "ICE", "RPG", "MINI", "TWIN"][Number(b.dataset.weapon) - 1];
    else delete b.dataset.short;
    b.disabled = !!missionTools && Number(b.dataset.weapon) > Number(unlocked);
    b.classList.toggle("selected", b.dataset.weapon === number);
  }
}
// Keep URLs relative to the served game even when installed under a Pages subpath.
async function gameResponse(path, options = {}) {
  const url = new URL(path, location.href);
  if (url.origin !== location.origin || !["http:", "https:"].includes(url.protocol))
    throw Error("Invalid game asset URL: " + path);
  const response = await fetch(url, { mode: "same-origin", ...options });
  if (!response.ok) throw Error(path + " (HTTP " + response.status + ")");
  return response;
}

function writeGameFile(path, data) {
  if (path.endsWith(".glb")) {
    const header = new DataView(data.buffer, data.byteOffset, data.byteLength);
    if (data.length < 12 || header.getUint32(0) !== 0x676c5446 || header.getUint32(8, true) !== data.length)
      throw Error(path + " (incomplete or invalid GLB)");
  }
  const slash = path.lastIndexOf("/");
  if (slash >= 0) Module.FS.mkdirTree("/" + path.slice(0, slash));
  Module.FS.writeFile("/" + path, data);
}

async function loadFiles(paths, cache = "default") {
  const missing = new Map();
  let next = 0;
  async function worker() {
    while (next < paths.length) {
      const path = paths[next++];
      try {
        const response = await gameResponse(path, { cache });
        writeGameFile(path, new Uint8Array(await response.arrayBuffer()));
      } catch (error) {
        missing.set(path, error);
      }
    }
  }
  await Promise.all(Array.from({ length: Math.min(6, paths.length) }, worker));
  return missing;
}

async function loadHall(manifest) {
  let missing = await loadFiles(manifest.files);
  if (!missing.size) return;
  missing = await loadFiles([...missing.keys()], "reload");
  if (!missing.size) return;
  const recovery = manifest.recovery;
  const [path, firstError] = missing.entries().next().value;
  if (!recovery) throw Error("Could not load " + path + ": " + firstError.message);
  // Pages supports byte ranges. A static host that ignores Range sends the full file.
  const indices = manifest.files.map((name, i) => (missing.has(name) ? i : -1)).filter((i) => i >= 0);
  const { offsets, file } = recovery;
  const start = offsets[indices[0]];
  const end = offsets[indices.at(-1) + 1];
  if (start === end) {
    for (const i of indices) writeGameFile(manifest.files[i], new Uint8Array(0));
    return;
  }
  try {
    const response = await gameResponse(file, { headers: { Range: "bytes=" + start + "-" + (end - 1) } });
    const data = new Uint8Array(await response.arrayBuffer());
    const partial = response.status === 206;
    if (
      data.length !== (partial ? end - start : offsets.at(-1)) ||
      (partial && response.headers.get("Content-Range") !== `bytes ${start}-${end - 1}/${offsets.at(-1)}`)
    )
      throw Error("Incomplete startup recovery download");
    const base = partial ? start : 0;
    for (const i of indices)
      writeGameFile(manifest.files[i], data.subarray(offsets[i] - base, offsets[i + 1] - base));
  } catch (error) {
    throw Error("Could not load " + path + ": " + firstError.message + ". Recovery: " + error.message);
  }
}

async function readManifest() {
  try {
    return await (await gameResponse("manifest.json", { cache: "no-cache" })).json();
  } catch {
    return (await gameResponse("manifest.json", { cache: "reload" })).json();
  }
}

var Module = {
  canvas,
  noInitialRun: true,
  hallHUD: updateHUD,
  printErr: (msg) => console.warn(msg),
  onRuntimeInitialized: async () => {
    try {
      const manifest = await readManifest();
      Module.fetchHallPack = async (day) => {
        const missing = await loadFiles(manifest.missions[day] || []);
        if (missing.size) console.warn(missing.values().next().value);
        Module._hall_pack_ready(day, Number(missing.size === 0));
      };
      await loadHall(manifest);
      const missingEntries = await loadFiles(manifest.entries);
      if (missingEntries.size) await loadFiles([...missingEntries.keys()], "reload");
      Module.FS.mkdirTree("/profile");
      try {
        Module.FS.mount(Module.IDBFS, {}, "/profile");
        await new Promise((resolve, reject) => Module.FS.syncfs(true, (e) => (e ? reject(e) : resolve())));
      } catch {
        storageWarning();
      }
      const config = JSON.parse(Module.FS.readFile("/server.json", { encoding: "utf8" }));
      let saved = {};
      try {
        saved = JSON.parse(localStorage.getItem("lantern-room") || "{}") || {};
      } catch {}
      settings = {
        endpoint: params.get("server") || saved.endpoint || config.endpoint || "",
        room: params.get("room") || saved.room || config.room || "friends",
      };
      const args = ["--root", "/"];
      const loopback = ["localhost", "127.0.0.1", "[::1]"].includes(location.hostname);
      if (loopback && params.get("preview") === "day1") {
        Module.FS.mkdirTree("/preview-clock");
        args.push("--fixture", "/preview-clock", "--test-clock", "1796079600");
      }
      if (settings.endpoint) args.push("--endpoint", settings.endpoint, "--room", settings.room);
      Module.callMain(args);
      ready = true;
      Module._hall_device(Number(touch), 0);
      Module._hall_tune(9, Number(matchMedia("(prefers-reduced-motion: reduce)").matches));
      document.addEventListener("visibilitychange", () => {
        if (!document.hidden) Module._hall_device(Number(touch), 1);
      });
      resize();
      menu(true);
      $("enter").disabled = false;
      $("enter").textContent = "Enter the hall";
      $("loading").textContent = "";
      if (window.installHallXR) window.installHallXR();
    } catch (e) {
      $("loading").textContent = "The hall could not open. " + (e.message || e);
      $("enter").hidden = true;
      $("retryLoad").hidden = false;
      $("retryLoad").onclick = () => location.reload();
      console.error(e);
    }
  },
};
